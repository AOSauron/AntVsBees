package ants;

import core.Ant;

public interface Containing {
	
	public boolean AddAnInsect(Ant one);
	public boolean DelInsect(Ant one);
	public Ant ObtainInsect();
	
	}
