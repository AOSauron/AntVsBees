package ants;

import core.Ant;
import core.AntColony;

public class WallAnt extends Ant  {
	/**
	 * Creates a new Wall Ant
	 */
	public WallAnt () {
		super(4,4);			/// WallAnt Nourriture:4 Armure:4
	}

	@Override
	public void action (AntColony colony) {
		
	}

}


