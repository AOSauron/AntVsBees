package ants;

public interface Damaging {
	
	public int getDamage();

	public void setDamage(int set);

}
