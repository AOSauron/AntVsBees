package core;

import core.Place;

public class Water extends Place {
	
//	private String name; // a name we can use for debugging
//	private Place exit; // where you leave this place to
//	private Place entrance; // where you enter this place from
//	private ArrayList<Bee> bees; // bees currently in the place
//	private Ant ant; // ant (singular) currently in the place


public Water(String name, Place exit) {
	super(name,exit);
	}

}
