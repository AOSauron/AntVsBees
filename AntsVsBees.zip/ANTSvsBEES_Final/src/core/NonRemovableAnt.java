package core;

public interface NonRemovableAnt {
	//Cette interface n'est juste l� que pour caract�riser le fait d'�tre supprimable pour une fourmi
}
